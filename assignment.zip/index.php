<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv = "refresh" content = "0; url = assignment/searchEmp.php" />
    </head>

    <body>
    </body>
</html>
