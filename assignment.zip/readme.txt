#!/bin/bash -ex
# Updated to use Amazon Linux 2
sudo yum -y update
sudo yum -y install httpd php mysql php-mysql
sudo amazon-linux-extras install -y lamp-mariadb10.2-php7.2 php7.2
sudo yum install -y httpd mariadb-server
sudo /usr/bin/systemctl enable httpd
sudo /usr/bin/systemctl start httpd
cd /var/www/html
sudo yum install git -y
sudo git clone https://github.com/lohcc-pm19/cloud_assignment.git
sudo mv cloud_assignment/* /var/www/html
sudo unzip assignment.zip
sudo rm -r cloud_assignment
sudo rm assignment.zip
cd assignment
sudo php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
sudo php -r "if (hash_file('sha384', 'composer-setup.php') === '55ce33d7678c5a611085589f1f3ddf8b3c52d662cd01d4ba75c0ee0459970c2200a51f492d557530c71c15d8dba01eae') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
sudo php composer-setup.php
sudo php -r "unlink('composer-setup.php');"
sudo php composer.phar require aws/aws-sdk-php

------connect database
mysql -u root -p -h assignment-db.cjzyxzcma6it.us-east-1.rds.amazonaws.com
show databases;
create database name;
use name;

----connect s3
aws s3 ls s3://myassignbucket1010