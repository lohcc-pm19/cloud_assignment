<?php
	include 's3_config.php';

	function put_object() {
		$emp_id = $_POST['emp_id'];
		$file = $_FILES["emp_image_file"]["tmp_name"];
		$GLOBALS['keyname'] = $emp_id . "_image_file_" . rand(10,100);

		try {
			$img_s3 = $GLOBALS['s3']->putObject(array(
				'Bucket' => $GLOBALS['bucketName'],
				'Key'    => $GLOBALS['keyname'],
				'SourceFile'   => $file,
				'ACL' => 'public-read'
			));

			$GLOBALS['img_url'] = $img_s3['ObjectURL'];

			return true;
		} catch (S3Exception $e) {
			return false;
		}
	}

	function delete_object() {
		try {
			$GLOBALS['s3']->deleteObject(array(
				'Bucket' => $GLOBALS['bucketName'],
				'Key' => $GLOBALS['keyToDelete'][0]['keyname'],
			));

			return true;
		} catch (S3Exception $e){
			return false;
		}
	}
?>