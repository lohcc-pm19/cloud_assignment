<?php 
	include 's3_operation.php';

	function insert_data() {
		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');

		$emp_id = $_POST['emp_id'];
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$department = $_POST['department'];
		$position = $_POST['position'];
		$salary = $_POST['salary'];
		$success = false;

		$sql = "INSERT INTO employees (emp_id, first_name, last_name, department, position, salary) 
				VALUES ('$emp_id', '$first_name', '$last_name', '$department', '$position', '$salary')";

		if ($db->query($sql))
			$success = true;

		$db->close();

		if ($success) {
			$success = put_object();

			if ($success) {
				insert_image_url();
	
				header("location:operation_success.php?type=1&emp_id=" . $emp_id);
				exit();
			}
			else
				echo "<script> alert('Fail to add in employee image into s3'); window.location.href='editEmp.php?type=1'; </script>";
		}
		else
			echo "<script> alert('Fail to add in new Employee'); window.location.href='editEmp.php?type=1'; </script>";
	} 

	function insert_image_url() {
		$emp_id = $_POST['emp_id'];
		$keyname = $GLOBALS['keyname'];
		$img_url = $GLOBALS['img_url'];
		$success = false;

		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');
		$sql = "INSERT INTO employeeImgs (keyname, img_url, emp_id) 
				VALUES ('$keyname', '$img_url', '$emp_id')";

		if ($db->query($sql))
			$success = true;

		$db->close();

		if(!$success)
			echo "<script> alert('Fail to add in employee image url'); window.location.href='editEmp.php?type=1'; </script>";
	} 

    function update_data() {
		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');

		$emp_id = $_POST['emp_id'];
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$department = $_POST['department'];
		$position = $_POST['position'];
		$salary = $_POST['salary'];
		$success = false;

		$sql = "UPDATE employees 
				SET first_name = '$first_name', last_name = '$last_name', 
				department = '$department', position = '$position', salary = $salary
				WHERE emp_id = '$emp_id'";

		if ($db->query($sql))
			$success = true;

		if ($success) {
			if ($_FILES["emp_image_file"]["size"] != 0) {
				$sql = "SELECT keyname FROM employeeImgs WHERE emp_id = '$emp_id'";
				$result = $db->query($sql);
				$GLOBALS['keyToDelete'] = mysqli_fetch_all($result, MYSQLI_ASSOC);

				if (count($GLOBALS['keyToDelete']) == 0)
					$success = false;

				if ($success) {
					$success = delete_object() && put_object();
					update_image_url();
				}
			}

			$db->close();

			if ($success) {
				header("location:operation_success.php?type=1&emp_id=" . $emp_id);
				exit();
			}
			else
				echo "<script> alert('Fail to update the employee image in s3'); window.location.href='searchEmp.php'; </script>";
		}
		else {
			$db->close();
			echo "<script> alert('Fail to update the Employee Info'); window.location.href='searchEmp.php'; </script>";
		}
	}

	function update_image_url() {
		$emp_id = $_POST['emp_id'];
		$img_url = $GLOBALS['img_url'];
		$keyname = $GLOBALS['keyname'];
		$success = false;

		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');
		$sql = "UPDATE employeeImgs 
				SET keyname = '$keyname', img_url = '$img_url'
				WHERE emp_id = '$emp_id'";

		if ($db->query($sql))
			$success = true;

		$db->close();

		if(!$success)
			echo "<script> alert('Fail to update the employee image url'); window.location.href='searchEmp.php'; </script>";
	} 

    function delete_data() {
		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');

		$emp_id = $_GET['emp_id'];

		$sql = "SELECT keyname FROM employeeImgs WHERE emp_id = '$emp_id'";
		$result = $db->query($sql);
		$GLOBALS['keyToDelete'] = mysqli_fetch_all($result, MYSQLI_ASSOC);
		$success = true;

		if (count($GLOBALS['keyToDelete']) == 0)
			$success = false;

		if ($success) {
			delete_object();

			$sql = "DELETE FROM employeeImgs WHERE emp_id = '$emp_id'";
			$db->query($sql);
			$success = false;
	
			if ($db->affected_rows > 0)
				$success = true;
	
			if ($success) {
				$sql = "DELETE FROM employees WHERE emp_id = '$emp_id'";
				$db->query($sql);
				$success = false;
	
				if ($db->affected_rows > 0)
					$success = true;
	
				$db->close();
	
				if ($success) {
					header("location:operation_success.php?type=2&emp_id=" . $emp_id);
					exit();
				}
				else
					echo "<script> alert('Fail to delete the Employee Info'); window.location.href='searchEmp.php'; </script>";
			}
			else {
				$db->close();
				echo "<script> alert('Fail to delete the employee img url'); window.location.href='searchEmp.php'; </script>";
			}
		}
		else {
			$db->close();
			echo "<script> alert('Fail to delete the employee img from s3'); window.location.href='searchEmp.php'; </script>";
		}
	}

	function get_lastest_id() {
		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');

		$sql = "SELECT emp_id FROM employees ORDER BY emp_id DESC LIMIT 1";
		$result = $db->query($sql);
		$result_fetch = mysqli_fetch_all($result, MYSQLI_ASSOC);

		if (count($result_fetch) != 0) {
			$id_1 =  substr($result_fetch[0]['emp_id'], 0, 1);
			$id_2 = (int)substr($result_fetch[0]['emp_id'], 1);
			$id_2++;
			$GLOBALS['emp_id'] = $id_1 . str_pad($id_2, 3, "0", STR_PAD_LEFT);
		}
		else
			$GLOBALS['emp_id'] = 'E001';

		$db->close();
	}

    function get_data_all() {
		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');

		$sql = "SELECT * FROM employees e";
		$result = $db->query($sql);
		$GLOBALS['result_fetch'] = mysqli_fetch_all($result, MYSQLI_ASSOC);
		$success = true;

		if (count($GLOBALS['result_fetch']) == 0)
			$success = false;

		$db->close();

		if (!$success)
			echo "<script> alert('Fail to get the Employee Info'); window.location.href='searchEmp.php'; </script>";
	}


	function get_data() {
		$db = new mysqli($GLOBALS['host'], $GLOBALS['user'], $GLOBALS['pass'], $GLOBALS['db_name']) or die('Unable to connect');

		$emp_id = $_GET['emp_id'];

		$sql = "SELECT * FROM employees WHERE emp_id = '$emp_id'";
		$result = $db->query($sql);
		$result_fetch = mysqli_fetch_all($result, MYSQLI_ASSOC);
		$success = true;

		if (count($result_fetch) == 0)
			$success = false;

		if ($success) {
			$GLOBALS['emp_id'] = $result_fetch[0]['emp_id'];
			$GLOBALS['first_name'] = $result_fetch[0]['first_name'];
			$GLOBALS['last_name'] = $result_fetch[0]['last_name'];
			$GLOBALS['department'] = $result_fetch[0]['department'];
			$GLOBALS['position'] = $result_fetch[0]['position'];
			$GLOBALS['salary'] = $result_fetch[0]['salary'];

			$sql = "SELECT img_url FROM employeeImgs WHERE emp_id = '$emp_id'";
			$result = $db->query($sql);
			$result_fetch = mysqli_fetch_all($result, MYSQLI_ASSOC);
			$success = true;

			if (count($result_fetch) == 0)
				$success = false;

			$db->close();

			if ($success)
				$GLOBALS['img_url'] = $result_fetch[0]['img_url'];
			else
				echo "<script> alert('Fail to get the Employee Image'); window.location.href='searchEmp.php'; </script>";
		}
		else {
			$db->close();
			echo "<script> alert('Fail to get the Employee Info'); window.location.href='searchEmp.php'; </script>";
		}
	}
?>