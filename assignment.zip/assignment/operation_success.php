<!DOCTYPE html>

<?php 
	include 'database_config.php';
	include 'database_operation.php';
	
	if ($_GET['type']==1)
		get_data();
	else
		$emp_id = $_GET['emp_id'];
?>

<html>
	<head>
		<title><?php if ($_GET['type'] == 1) echo 'Update Employee Information'; else echo 'Delete Employee Information'; ?></title>

		<style>
			body {
				font-family: Verdana, Geneva, Tahoma, sans-serif;
				font-size: 20px;
				margin: auto;
				width: 960px;
			}

			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #2a007f;
				overflow-x: hidden;
				padding-top: 50px;
			}

			.sidenav a {
				height: 40px;
				padding: 18px 8px 6px 16px;
				text-decoration: none;
				color: #ffffff;
				display: block;
			}
			
			.sidenav a:hover {
				background-color: #f1f1f1;
				color: black;
			}

			.main {
				margin-left: 160px;
				padding: 0px 10px;
				text-align: center;
				margin-bottom: 50px;
			}

			.success{
				display: block;
				background-color: #abe350;
				color: black;
				height: 80px;
				line-height: 80px;
			}

			img#success_icon{
				float: left;
			}

			td:first-of-type{
				font-size: 14pt;
				width: 200px;
				height: 25px;
				text-align: left;
			}

			td{
				width: 400px;
				height: 25px;
				font-size: 14pt;
			}
		</style>
	</head>

	<body>
		<div id="nav" class="sidenav">
			<a href="searchEmp.php">Employee Info</a>
			<a href="editEmp.php?type=1">Add Employee</a>
		</div>

		<div id="main" class="main">
				<h1 style="color: DodgerBlue"><font size="+10">Employee Database</font></h1>

				<img src="success.png" alt="success_icon" id="success_icon">

				<div id="success" class="success">
					<h1><?php if ($_GET['type'] == 1) echo '<h1>SAVE SUCCESSFUL</h1><br>'; else echo '<h1>DELETE SUCCESSFUL</h1><br>'; ?></h1><br>
				</div>

				<h3>Following Employee has been <?php  if ($_GET['type'] == 1) echo 'updated to'; else echo 'deleted from'; ?> the database</h3><br><br>

				<?php 
					if ($_GET['type'] == 1)
						echo '<img src="' . $img_url . '" alt="Employee_photo" height="250px" width="250px"> <br><br>
								<table>
									<tbody cellspacing="10" cellpadding="8">
									<tr>
										<td><h3>Employee Id: </td>
										<td>' . $emp_id . '</h3></td>
									</tr>
									<tr>
										<td><h3>First Name: </td>
										<td>' .  $first_name . '</h3></td>
									</tr>
									<tr>
										<td><h3>Last Name: </td>
										<td>' . $last_name . '</h3></td>
									</tr>
									<tr>
										<td><h3>Department: </td>
										<td>' . $department . '</h3></td>
									</tr>
									<tr>
										<td><h3>Position: </td>
										<td>' . $position . '</h3></td>
									</tr>
									<tr>
										<td><h3>Salary: </td>
										<td>' . $salary . '</h3></td>
									</tr>
									</tbody>
								</table>';
					else
						echo '<h2>Employee Id: ' . $emp_id . '</h2><br>';
				?>
		</div>
	</body>
</html>
