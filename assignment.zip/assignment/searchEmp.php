<!DOCTYPE html>

<?php 

	include 's3_config.php';

	if (isset($_GET['run'])) {
		if ($_GET['type'] == 1) {
			header("location:empDetail.php?emp_id=" . $_POST['emp_id']);
			exit();
		}
		else {
			header("location:editEmp.php?type=2&emp_id=" . $_POST['emp_id']);
			exit();
		}
	}
?>

<html>
	<head>
		<title>Employee Information</title>

		<style>
			body {
				font-family: Verdana, Geneva, Tahoma, sans-serif;
				font-size: 20px;
				margin: auto;
				width: 960px;
			}

			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #2a007f;
				overflow-x: hidden;
				padding-top: 50px;
			}

			.sidenav a {
				height: 40px;
				padding: 18px 8px 6px 16px;
				text-decoration: none;
				color: #ffffff;
				display: block;
			}
			
			.sidenav a:hover {
				background-color: #f1f1f1;
				color: black;
			}

			.main {
				margin-left: 160px;
				padding: 0px 10px;
				text-align: center;
			}

			button{
				background-color: #2a007f;
				height: 60px; 
				width: 200px; 
				color: white; 
				font-size: 14pt;
				float: center;
				margin-left: 10px;
			}

			button:hover{
				background-color: #004cbe;
			}

			.main a{
				background-color: #3300aa;
				height: 60px; 
				width: 400px; 
				color: white; 
				font-size: 14pt;
				text-decoration: none;
				display: block;
				line-height: 60px;
				margin: auto;
				margin-top: 10px;
			}

			.main a:hover{
				background-color: #004cbe;
			}

			h1 {
				margin-bottom: 50px;
			}

			input {
				margin-bottom: 70px;
			}
		</style>
	</head>

	<body>
		<div id="nav" class="sidenav">
			<a href="searchEmp.php">Employee Info</a>
			<a href="editEmp.php?type=1">Add Employee</a>
		</div>

		<div id="main" class="main">
			<h1 style="color: DodgerBlue"><font size="+10">Employee Database</font></h1>

			<form autocomplete="on" method = "POST" onSubmit="return check_input()">
				<h2 style="color: grey">Enter Employee ID</h2>
					<br>
					<br>
					Employee ID: <input style="height:25px;font-size:14pt;" type="text" name="emp_id" id="emp_id" autofocus size="40"><br><br>
					<button type="submit" formaction= "searchEmp.php?type=1&run=true">View Info</button>
					<button type="submit" formaction= "searchEmp.php?type=2&run=true">Modify Info</button>
			</form>
			
			<br>

			<a href="empList.php">Employee List</a><br><br>
		</div>
	</body>
</html>

<script type="text/javascript">
	function check_input() {
		var emp_id = document.getElementById("emp_id").value;
		document.getElementById("emp_id").value = emp_id.toUpperCase()
		
		if (emp_id.length == 0) 
			alert("Please fill in the employee id.");
		else
			return true;

		return false;
	}
</script>