<?php 
    include 'database_config.php';
    include 'database_operation.php';

	get_data_all();
?>

<html>
	<head>
		<title>Employee Information</title>

        <style>
			body {
				font-family: Verdana, Geneva, Tahoma, sans-serif;
				font-size: 20px;
				margin: auto;
				width: 960px;
			}

			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #2a007f;
				overflow-x: hidden;
				padding-top: 50px;
			}

			.sidenav a {
				height: 40px;
				padding: 18px 8px 6px 16px;
				text-decoration: none;
				color: #ffffff;
				display: block;
			}
			
			.sidenav a:hover {
				background-color: #f1f1f1;
				color: black;
			}

			.main {
				margin-left: 160px;
				padding: 0px 10px;
				text-align: center;
			}

			.main a{
				background-color: #2a007f;
				height: 60px; 
				width: 200px; 
				color: white; 
				font-size: 14pt;
				display:block;
				text-decoration: none;
				margin: auto;
				margin-top: 50px;
				line-height: 60px;
			}

			.main a:hover{
				background-color: #004cbe;
			}

			table th{
				border: 1px solid black;
				text-align: center;
				background-color: #2a007f;
				color: white;
			}

			table td{
				border: 1px solid black;
				border-collapse: collapse;
			}
		</style>
	</head>

	<body>
        <div id="nav" class="sidenav">
			<a href="searchEmp.php">Employee Info</a>
			<a href="editEmp.php?type=1">Add Employee</a>
		</div>

        <div id="main" class="main">
            <h1 style="color: DodgerBlue"><font size="+10">Employee Database</font></h1>

            <table id="list" cellspacing="0" cellpadding="8">
                <tbody>
                    <tr>
                        <th>Employee ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Department</th>
                        <th>Position</th>
                        <th>Salary</th>
                    </tr>

                    <?php 
                        foreach ($result_fetch as $result)
                            echo '<tr>
                                    <td>' . $result['emp_id'] . '</td>
                                    <td>' . $result['first_name'] . '</td>
                                    <td>' . $result['last_name'] . '</td>
                                    <td>' . $result['department'] . '</td>
                                    <td>' . $result['position'] . '</td>
                                    <td>' . $result['salary'] . '</td>
                                </tr>';
                    ?>
                </tbody>
            </table>
            
            <br>

            <a href="searchEmp.php">Back</a><br><br>
        </div>
	</body>
</html>