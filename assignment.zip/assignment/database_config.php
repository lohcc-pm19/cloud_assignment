<?php 
    // $host = 'localhost';
    // $user = 'root'; 
    // $pass = ''; 
    // $db_name = 'assignment'; 
    $host = 'assignment-db.cjzyxzcma6it.us-east-1.rds.amazonaws.com';
    $user = 'root';
    $pass = 'root123456';
    $db_name = 'db_assign';

    $db = new mysqli($host, $user, $pass, $db_name) or die('Unable to connect');
    $sql = "SHOW TABLES LIKE 'employees'";
    $result = $db->query($sql);
    $result_fetch = mysqli_fetch_all($result, MYSQLI_ASSOC);

    if (count($result_fetch) == 0) {
        $sql = "CREATE TABLE employees (
            emp_id VARCHAR(50) PRIMARY KEY,
            first_name VARCHAR(50),
            last_name VARCHAR(50),
            department VARCHAR(50),
            position VARCHAR(50),
            salary INT(5)
        )";

        if (!$db->query($sql))
            echo '<script>alert("Unable to create employees table!")</script>';
    }

    $sql = "SHOW TABLES LIKE 'employeeImgs'";
    $result = $db->query($sql);
    $result_fetch = mysqli_fetch_all($result, MYSQLI_ASSOC);

    if (count($result_fetch) == 0) {
        $sql = "CREATE TABLE employeeImgs (
            keyname VARCHAR(50) PRIMARY KEY,
            img_url VARCHAR(100),
            emp_id VARCHAR(50),
            FOREIGN KEY (emp_id) REFERENCES employees(emp_id)
        )";

        if (!$db->query($sql))
            echo '<script>alert("Unable to create employeeImgs table!")</script>';
    }
        
    $db->close()
?>