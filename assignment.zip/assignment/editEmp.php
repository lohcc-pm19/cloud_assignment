<!DOCTYPE html>

<?php 
	include 'database_config.php';
	include 'database_operation.php';

	$emp_id = '';
	$first_name = '';
	$last_name = '';
	$department = 'Choose';
	$position = '';
	$salary = null;

	if ($_GET['type'] == 1) {
		if (isset($_GET['run']))
			insert_data();
		else
			get_lastest_id();
	}
	else {
		if (isset($_GET['run']))
			update_data();
		else
			get_data();
	}
?>

<html>
	<head>
		<title><?php if ($_GET['type'] == 1) echo "Add Employee Information"; else echo "Modify Employee Information";?></title>

		<style>
			body {
				font-family: Verdana, Geneva, Tahoma, sans-serif;
				font-size: 20px;
				margin: auto;
				width: 960px;
			}

			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #2a007f;
				overflow-x: hidden;
				padding-top: 50px;
			}

			.sidenav a {
				height: 40px;
				padding: 18px 8px 6px 16px;
				text-decoration: none;
				color: #ffffff;
				display: block;
			}
			
			.sidenav a:hover {
				background-color: #f1f1f1;
				color: black;
			}

			.main {
				margin-left: 160px;
				padding: 0px 10px;
				text-align: center;
			}

			td:first-of-type{
				font-size: 14pt;
				width: 200px;
				text-align: left;
			}

			input{
				width: 400px;
				height: 25px;
				font-size: 14pt;
				color: grey;
			}

			select{
				width: 400px;
				height: 25px;
				font-size: 14pt;
			}

			button{
				background-color: #2a007f;
				height: 45px; 
				width: 200px; 
				color: white; 
				font-size: 14pt;
			}

			button:hover{
				background-color: #004cbe;
			}
		</style>
	</head>

	<body>
		<div id="nav" class="sidenav">
			<a href="searchEmp.php">Employee Info</a>
			<a href="editEmp.php?type=1">Add Employee</a>
		</div>

		<div id="main" class="main">
			<h1 style="color: DodgerBlue">Employee Database</h1>

			<?php if ($_GET['type'] == 2) echo '<img src="' . $img_url . '" alt="Employee_photo" height="250px" width="250px"> <br><br>'?>

			<form action= '<?php echo "editEmp.php?type=".$_GET['type']."&run=true" ?>' method = "POST" enctype="multipart/form-data" onSubmit="return check_input()">
				<table class="employeeInfo" cellspacing="10" cellpadding="8">
					<tbody>
						<tr>
							<td>Employee ID: </td>
							<td><input type="text" name="emp_id" id ="emp_id" value= "<?php echo $emp_id ?>" disabled autofocus size="40"></td>
						</tr>
						
						<tr>
							<td>First Name: </td>
							<td><input type="text" name="first_name" id ="first_name" value= "<?php echo $first_name ?>" ></td>
						</tr>

						<tr>
							<td>Last Name: </td>
							<td><input type="text" name="last_name" id ="last_name" value= "<?php echo $last_name ?>" ></td>
						</tr>

						<tr>
							<td>Department: </td>
							<td><select name="department" id ="department" >
								<option value="Choose" <?php if ($department == 'Choose') echo 'selected="selected"'; ?>>Choose</option>
								<option value="IT" <?php if ($department == 'IT') echo 'selected="selected"'; ?>> IT</option>
								<option value="Human Resources" <?php if ($department == 'Human Resources') echo 'selected="selected"'; ?>>Human Resources</option>
								<option value="Account and Finance" <?php if ($department == 'Account and Finance') echo 'selected="selected"'; ?>>Accounting and Finance</option>
								<option value="Marketing" <?php if ($department == 'Marketing') echo 'selected="selected"'; ?>> Marketing</option>
								<option value="Research and Development (R&D)" <?php if ($department == 'Research and Development (R&D)') echo 'selected="selected"'; ?>>Research and Development (R&D)</option>
								<option value="Production" <?php if ($department == 'Production') echo 'selected="selected"'; ?>>Production</option>
							</select></td>
						</tr>

						<tr>
							<td>Position: </td>
							<td><input type="text" name="position" id ="position" value= "<?php echo $position ?>" ></td>
						</tr>

						<tr>
							<td>Salary: </td>
							<td><input type="number" name="salary" id ="salary" value= "<?php echo $salary ?>" ></td>
						</tr>
					</tbody>
        		</table>

				<br>
				
				Image: <input type='file' name="emp_image_file" id="emp_image_file" style="height:25px;font-size:14pt;color:grey;"> <br><br>

				<button type="submit"><?php if ($_GET['type'] == 1) echo "Add Employee"; else echo "Modify Employee";?></button>
			</form>
		</div>
	</body>
</html>

<script type="text/javascript">
	function check_input() {
		var first_name = document.getElementById("first_name").value.trim();
		var last_name = document.getElementById("last_name").value.trim();
		var department = document.getElementById("department").value;
		var position = document.getElementById("position").value.trim();
		var salary = document.getElementById("salary").value;
        var reg_exp_word = /^(\s*[a-zA-Z]+\s*)+$/i;

		if (!reg_exp_word.test(first_name)) 
			alert("Please fill in the valid first name.");
		else if (!reg_exp_word.test(last_name))
			alert("Please fill in the valid last name.");
		else if (department == "Choose")
			alert("Please select the department.");
		else if (!reg_exp_word.test(position))
			alert("Please fill in the valid position.");
		else if (salary <= 0 || salary == null)
			alert("Please fill in the valid salary.");
		else if (!validateImage())
			alert('Invalid file type');
		else {
			document.getElementById("emp_id").disabled = false;
			return true;
		}

		return false;
	}

	function validateImage() {
		var fileInput =document.getElementById('emp_image_file');
		var filePath = fileInput.value;
		var type = <?php echo $_GET['type'] ?>;

		if (type == 2 && filePath == '')
			return true;
			
		var allowedFormat = /(\.jpg|\.jpeg|\.png|\.gif)$/i;

		if (!allowedFormat.exec(filePath))
			return false;

		return true;
    }
</script>