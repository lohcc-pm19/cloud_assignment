<!DOCTYPE html>

<?php 
	include 'database_config.php';
	include 'database_operation.php';

	if (isset($_GET['run']))
		delete_data();
	else 
		get_data();
?>

<html>
	<head>
		<title>Employee Information</title>

		<style>
			body {
				font-family: Verdana, Geneva, Tahoma, sans-serif;
				font-size: 20px;
				margin: auto;
				width: 960px;
			}

			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #2a007f;
				overflow-x: hidden;
				padding-top: 50px;
			}

			.sidenav a {
				height: 40px;
				padding: 18px 8px 6px 16px;
				text-decoration: none;
				color: #ffffff;
				display: block;
			}
			
			.sidenav a:hover {
				background-color: #f1f1f1;
				color: black;
			}

			.main {
				margin-left: 160px;
				padding: 0px 10px;
				text-align: center;
				margin-top: 30px;
				margin-bottom: 50px;
			}

			td:first-of-type{
				font-size: 14pt;
				width: 200px;
				height: 25px;
				text-align: left;
			}

			td{
				width: 400px;
				height: 25px;
				font-size: 14pt;
			}

			.button a{
				background-color: #2a007f;
				height: 60px; 
				width: 200px; 
				color: white; 
				font-size: 14pt;
				display:inline-block;
				text-decoration: none;
				margin-top: 50px;
				line-height: 60px;
			}

			.button a:hover{
				background-color: #004cbe;
			}

			h1 {
				margin-bottom: 30px;
			}
		</style>
	</head>

	<body>
		<div id="nav" class="sidenav">
			<a href="searchEmp.php">Employee Info</a>
			<a href="editEmp.php?type=1">Add Employee</a>
		</div>

		<div id="main" class="main">
			<h1 style="color: DodgerBlue"><font size="+10">Employee Database</font></h1>

			<img src="<?php echo $img_url ?>" alt="Employee_photo" height='250px' width='250px'> <br><br>

			<table cellspacing="10" cellpadding="8">
				<tbody>
					<tr>
						<td>Employee ID: </td>
						<td><?php echo $emp_id ?></td>
					</tr>

					<tr>
						<td>First Name: </td>
						<td><?php echo $first_name ?></td>
					</tr>

					<tr>
						<td>Last Name: </td>
						<td><?php echo $last_name ?></td>
					</tr>

					<tr>
						<td>Department: </td>
						<td><?php echo $department ?></td>
					</tr>

					<tr>
						<td>Position: </td>
						<td><?php echo $position ?></td>
					</tr>

					<tr>
						<td>Salary: </td>
						<td><?php echo $salary ?></td>
					</tr>
					
				</tbody>
			</table>

			<div id="button" class="button">
				<a href="searchEmp.php">Back</a>
				<a href="empDetail.php?run=true&emp_id=<?php echo $emp_id ?>" onclick="return get_confirmation()">Delete</a>
			</div>			
		</div>
	</body>
</html>

<script type="text/javascript">
	function get_confirmation() {
		return confirm('Do you really want to delete the employee?');
	}
</script>